﻿namespace FootballManager.ViewModels.Users
{
    public class LoginForemViewModel
    {
        public string Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
